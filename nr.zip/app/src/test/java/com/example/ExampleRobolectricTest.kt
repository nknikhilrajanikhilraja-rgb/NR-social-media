package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.ScreenTab
import com.example.viewmodel.SocialViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NR", appName)
  }

  @Test
  fun `verify social viewmodel initialization and profile state`() {
    val viewModel = SocialViewModel()
    val state = viewModel.uiState.value

    assertEquals(ScreenTab.HOME, state.currentTab)
    assertNotNull(state.currentUser)
    assertEquals("nikhilraja", state.currentUser.username)
    assertTrue(state.posts.isNotEmpty())
    assertTrue(state.myPosts.isNotEmpty())

    // Test profile edit
    val updatedUser = state.currentUser.copy(bio = "Updated Bio Test")
    viewModel.updateCurrentUser(updatedUser)
    assertEquals("Updated Bio Test", viewModel.uiState.value.currentUser.bio)
  }
}
