package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.model.ScreenTab
import com.example.ui.auth.AuthScreen
import com.example.ui.components.CommentBottomSheet
import com.example.ui.components.CreatePostDialog
import com.example.ui.components.PostDetailDialog
import com.example.ui.explore.ExploreScreen
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.reels.ReelsScreen
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueLight
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NrSocialTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.SocialViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NrSocialTheme {
                NrSocialApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NrSocialApp(viewModel: SocialViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var isCreatePostOpen by remember { mutableStateOf(false) }

    val commentSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val coroutineScope = rememberCoroutineScope()

    // Handle back button when inspecting a sub-profile
    BackHandler(enabled = uiState.viewingUser != null) {
        viewModel.clearViewingUser()
    }

    if (!uiState.isLoggedIn) {
        AuthScreen(
            onLoginSuccess = { name, username ->
                viewModel.logIn(name, username)
                Toast.makeText(context, "Welcome to NR Social, @$username!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        )
        return
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep),
        bottomBar = {
            NavigationBar(
                containerColor = NavySurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("main_bottom_nav")
            ) {
                // HOME Tab
                NavigationBarItem(
                    selected = uiState.currentTab == ScreenTab.HOME && uiState.viewingUser == null,
                    onClick = { viewModel.selectTab(ScreenTab.HOME) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == ScreenTab.HOME && uiState.viewingUser == null)
                                Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "Home",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        unselectedIconColor = TextTertiary,
                        unselectedTextColor = TextTertiary,
                        indicatorColor = NavySurfaceElevated
                    ),
                    modifier = Modifier.testTag("tab_home")
                )

                // EXPLORE Tab
                NavigationBarItem(
                    selected = uiState.currentTab == ScreenTab.EXPLORE,
                    onClick = { viewModel.selectTab(ScreenTab.EXPLORE) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == ScreenTab.EXPLORE)
                                Icons.Filled.Search else Icons.Outlined.Search,
                            contentDescription = "Explore",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = { Text("Explore", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        unselectedIconColor = TextTertiary,
                        unselectedTextColor = TextTertiary,
                        indicatorColor = NavySurfaceElevated
                    ),
                    modifier = Modifier.testTag("tab_explore")
                )

                // REELS Tab
                NavigationBarItem(
                    selected = uiState.currentTab == ScreenTab.REELS,
                    onClick = { viewModel.selectTab(ScreenTab.REELS) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == ScreenTab.REELS)
                                Icons.Filled.PlayCircleFilled else Icons.Filled.PlayCircleOutline,
                            contentDescription = "Reels",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = { Text("Reels", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        unselectedIconColor = TextTertiary,
                        unselectedTextColor = TextTertiary,
                        indicatorColor = NavySurfaceElevated
                    ),
                    modifier = Modifier.testTag("tab_reels")
                )

                // PROFILE Tab
                val isProfileTabSelected = uiState.currentTab == ScreenTab.PROFILE
                NavigationBarItem(
                    selected = isProfileTabSelected,
                    onClick = {
                        viewModel.clearViewingUser()
                        viewModel.selectTab(ScreenTab.PROFILE)
                    },
                    icon = {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .border(
                                    width = if (isProfileTabSelected) 2.dp else 1.dp,
                                    color = if (isProfileTabSelected) NeonCyan else TextTertiary,
                                    shape = CircleShape
                                )
                        ) {
                            AsyncImage(
                                model = uiState.currentUser.avatarUrl,
                                contentDescription = "My Profile",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    },
                    label = { Text("Profile", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        unselectedIconColor = TextTertiary,
                        unselectedTextColor = TextTertiary,
                        indicatorColor = NavySurfaceElevated
                    ),
                    modifier = Modifier.testTag("tab_profile")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
        ) {
            when {
                // If viewing a user profile (either someone else or navigated to profile)
                uiState.viewingUser != null -> {
                    val user = uiState.viewingUser!!
                    ProfileScreen(
                        user = user,
                        posts = uiState.posts.filter { it.userId == user.id },
                        savedPosts = emptyList(),
                        isCurrentUser = user.id == uiState.currentUser.id,
                        onBackClick = { viewModel.clearViewingUser() },
                        onUpdateUser = { updated -> viewModel.updateCurrentUser(updated) },
                        onToggleFollow = { userId -> viewModel.toggleFollowUser(userId) },
                        onPostClick = { post -> viewModel.setSelectedPostDetail(post) },
                        onLogoutClick = { viewModel.logOut() }
                    )
                }

                uiState.currentTab == ScreenTab.HOME -> {
                    HomeScreen(
                        posts = uiState.posts,
                        stories = uiState.stories,
                        currentUser = uiState.currentUser,
                        onCreatePostClick = { isCreatePostOpen = true },
                        onLikeToggle = { postId -> viewModel.togglePostLike(postId) },
                        onSaveToggle = { postId -> viewModel.togglePostSave(postId) },
                        onCommentClick = { post -> viewModel.openCommentSheet(post) },
                        onAuthorClick = { userId -> viewModel.viewUserProfile(userId) }
                    )
                }

                uiState.currentTab == ScreenTab.EXPLORE -> {
                    ExploreScreen(
                        posts = uiState.posts,
                        onPostClick = { post -> viewModel.setSelectedPostDetail(post) }
                    )
                }

                uiState.currentTab == ScreenTab.REELS -> {
                    ReelsScreen(
                        reels = uiState.reels,
                        onLikeToggle = { reelId -> viewModel.toggleReelLike(reelId) },
                        onFollowToggle = { creatorUsername -> viewModel.toggleFollowCreator(creatorUsername) },
                        onCommentClick = { reel ->
                            Toast.makeText(context, "Comments for @${reel.creatorUsername}'s reel (Demo)", Toast.LENGTH_SHORT).show()
                        },
                        onCreatorClick = { creatorUsername ->
                            val user = if (creatorUsername == uiState.currentUser.username) {
                                uiState.currentUser
                            } else {
                                com.example.data.MockDataProvider.otherUsers.find { it.username == creatorUsername }
                            }
                            if (user != null) {
                                viewModel.viewUserProfile(user.id)
                            }
                        }
                    )
                }

                uiState.currentTab == ScreenTab.PROFILE -> {
                    ProfileScreen(
                        user = uiState.currentUser,
                        posts = uiState.myPosts,
                        savedPosts = uiState.posts.filter { it.isSavedByMe },
                        isCurrentUser = true,
                        onBackClick = null,
                        onUpdateUser = { updated -> viewModel.updateCurrentUser(updated) },
                        onToggleFollow = { },
                        onPostClick = { post -> viewModel.setSelectedPostDetail(post) },
                        onLogoutClick = { viewModel.logOut() }
                    )
                }
            }
        }
    }

    // Modal Create Post Dialog
    if (isCreatePostOpen) {
        CreatePostDialog(
            userAvatar = uiState.currentUser.avatarUrl,
            userName = uiState.currentUser.name,
            onDismiss = { isCreatePostOpen = false },
            onCreatePost = { caption, mediaUrl, isVideo, location ->
                viewModel.createPost(caption, mediaUrl, isVideo, location)
                isCreatePostOpen = false
                Toast.makeText(context, "Post published to NR feed!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Modal Comments Bottom Sheet
    uiState.activeCommentPost?.let { post ->
        CommentBottomSheet(
            comments = post.comments,
            currentUserAvatar = uiState.currentUser.avatarUrl,
            sheetState = commentSheetState,
            onDismiss = {
                coroutineScope.launch { commentSheetState.hide() }
                viewModel.closeCommentSheet()
            },
            onAddComment = { text ->
                viewModel.addCommentToPost(post.id, text)
            },
            onToggleCommentLike = { commentId ->
                viewModel.toggleCommentLike(post.id, commentId)
            }
        )
    }

    // Post Detail Dialog (when opening from profile or explore grid)
    uiState.selectedPostDetail?.let { post ->
        PostDetailDialog(
            post = post,
            onDismiss = { viewModel.setSelectedPostDetail(null) },
            onLikeToggle = { viewModel.togglePostLike(post.id) },
            onSaveToggle = { viewModel.togglePostSave(post.id) },
            onCommentClick = {
                viewModel.setSelectedPostDetail(null)
                viewModel.openCommentSheet(post)
            },
            onShareClick = {
                Toast.makeText(context, "Shared post by @${post.authorUsername}", Toast.LENGTH_SHORT).show()
            },
            onAuthorClick = {
                viewModel.setSelectedPostDetail(null)
                viewModel.viewUserProfile(post.userId)
            }
        )
    }
}
