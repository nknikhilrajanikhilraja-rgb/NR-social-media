package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.data.MockDataProvider
import com.example.model.Comment
import com.example.model.Post
import com.example.model.Reel
import com.example.model.ScreenTab
import com.example.model.Story
import com.example.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

data class SocialUiState(
    val isLoggedIn: Boolean = true,
    val currentTab: ScreenTab = ScreenTab.HOME,
    val currentUser: User = MockDataProvider.currentUser,
    val viewingUser: User? = null,
    val posts: List<Post> = MockDataProvider.getInitialPosts(),
    val myPosts: List<Post> = MockDataProvider.getUserPosts("user_me"),
    val stories: List<Story> = MockDataProvider.getInitialStories(),
    val reels: List<Reel> = MockDataProvider.getInitialReels(),
    val activeCommentPost: Post? = null,
    val activeCommentReel: Reel? = null,
    val selectedPostDetail: Post? = null
)

class SocialViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(SocialUiState())
    val uiState: StateFlow<SocialUiState> = _uiState.asStateFlow()

    fun selectTab(tab: ScreenTab) {
        _uiState.update { it.copy(currentTab = tab, viewingUser = null) }
    }

    fun viewUserProfile(userId: String) {
        val user = if (userId == _uiState.value.currentUser.id) {
            _uiState.value.currentUser
        } else {
            MockDataProvider.otherUsers.find { it.id == userId }
                ?: User(
                    id = userId,
                    name = "NR Creator",
                    username = userId.removePrefix("user_"),
                    avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
                    bio = "Social creator on NR Social Network.",
                    followersCount = 1200,
                    followingCount = 180,
                    postsCount = 5
                )
        }
        _uiState.update {
            it.copy(
                viewingUser = user,
                currentTab = ScreenTab.PROFILE
            )
        }
    }

    fun clearViewingUser() {
        _uiState.update { it.copy(viewingUser = null) }
    }

    fun updateCurrentUser(updatedUser: User) {
        _uiState.update { state ->
            // Also update any posts created by currentUser
            val updatedFeedPosts = state.posts.map { post ->
                if (post.userId == state.currentUser.id) {
                    post.copy(
                        authorName = updatedUser.name,
                        authorUsername = updatedUser.username,
                        authorAvatarUrl = updatedUser.avatarUrl
                    )
                } else post
            }

            val updatedMyPosts = state.myPosts.map { post ->
                post.copy(
                    authorName = updatedUser.name,
                    authorUsername = updatedUser.username,
                    authorAvatarUrl = updatedUser.avatarUrl
                )
            }

            state.copy(
                currentUser = updatedUser,
                viewingUser = if (state.viewingUser?.id == updatedUser.id) updatedUser else state.viewingUser,
                posts = updatedFeedPosts,
                myPosts = updatedMyPosts
            )
        }
    }

    fun toggleFollowUser(userId: String) {
        _uiState.update { state ->
            val isNowFollowed = !(state.viewingUser?.isFollowedByMe ?: false)
            val updatedViewing = state.viewingUser?.copy(
                isFollowedByMe = isNowFollowed,
                followersCount = if (isNowFollowed) state.viewingUser.followersCount + 1 else state.viewingUser.followersCount - 1
            )
            state.copy(viewingUser = updatedViewing)
        }
    }

    fun togglePostLike(postId: String) {
        _uiState.update { state ->
            val updateList = { list: List<Post> ->
                list.map { post ->
                    if (post.id == postId) {
                        val newLiked = !post.isLikedByMe
                        val newCount = if (newLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
                        post.copy(isLikedByMe = newLiked, likesCount = newCount)
                    } else post
                }
            }

            val updatedPosts = updateList(state.posts)
            val updatedMyPosts = updateList(state.myPosts)
            val updatedActiveCommentPost = if (state.activeCommentPost?.id == postId) {
                updatedPosts.find { it.id == postId } ?: state.activeCommentPost
            } else state.activeCommentPost

            state.copy(
                posts = updatedPosts,
                myPosts = updatedMyPosts,
                activeCommentPost = updatedActiveCommentPost
            )
        }
    }

    fun togglePostSave(postId: String) {
        _uiState.update { state ->
            val updateList = { list: List<Post> ->
                list.map { post ->
                    if (post.id == postId) post.copy(isSavedByMe = !post.isSavedByMe) else post
                }
            }
            state.copy(
                posts = updateList(state.posts),
                myPosts = updateList(state.myPosts)
            )
        }
    }

    fun openCommentSheet(post: Post) {
        _uiState.update { it.copy(activeCommentPost = post, activeCommentReel = null) }
    }

    fun closeCommentSheet() {
        _uiState.update { it.copy(activeCommentPost = null, activeCommentReel = null) }
    }

    fun addCommentToPost(postId: String, text: String) {
        _uiState.update { state ->
            val newComment = Comment(
                id = UUID.randomUUID().toString(),
                authorName = state.currentUser.name,
                authorUsername = state.currentUser.username,
                authorAvatarUrl = state.currentUser.avatarUrl,
                text = text,
                timestamp = "Just now",
                likesCount = 0
            )

            val updatedPosts = state.posts.map { post ->
                if (post.id == postId) {
                    val newComments = listOf(newComment) + post.comments
                    post.copy(
                        comments = newComments,
                        commentsCount = post.commentsCount + 1
                    )
                } else post
            }

            val updatedActivePost = updatedPosts.find { it.id == postId } ?: state.activeCommentPost

            state.copy(
                posts = updatedPosts,
                activeCommentPost = updatedActivePost
            )
        }
    }

    fun toggleCommentLike(postId: String, commentId: String) {
        _uiState.update { state ->
            val updatedPosts = state.posts.map { post ->
                if (post.id == postId) {
                    val updatedComments = post.comments.map { comment ->
                        if (comment.id == commentId) {
                            val newLiked = !comment.isLikedByMe
                            comment.copy(
                                isLikedByMe = newLiked,
                                likesCount = if (newLiked) comment.likesCount + 1 else (comment.likesCount - 1).coerceAtLeast(0)
                            )
                        } else comment
                    }
                    post.copy(comments = updatedComments)
                } else post
            }

            val updatedActivePost = updatedPosts.find { it.id == postId } ?: state.activeCommentPost
            state.copy(posts = updatedPosts, activeCommentPost = updatedActivePost)
        }
    }

    fun createPost(caption: String, mediaUrl: String, isVideo: Boolean, location: String?) {
        val currentUser = _uiState.value.currentUser
        val newPost = Post(
            id = "post_${System.currentTimeMillis()}",
            userId = currentUser.id,
            authorName = currentUser.name,
            authorUsername = currentUser.username,
            authorAvatarUrl = currentUser.avatarUrl,
            isVerified = currentUser.isVerified,
            timestamp = "Just now",
            caption = caption,
            mediaUrl = mediaUrl,
            isVideo = isVideo,
            videoDuration = if (isVideo) "0:30" else "",
            likesCount = 1,
            isLikedByMe = true,
            commentsCount = 0,
            location = location,
            tags = extractHashtags(caption)
        )

        _uiState.update { state ->
            state.copy(
                posts = listOf(newPost) + state.posts,
                myPosts = listOf(newPost) + state.myPosts,
                currentTab = ScreenTab.HOME
            )
        }
    }

    fun toggleReelLike(reelId: String) {
        _uiState.update { state ->
            val updatedReels = state.reels.map { reel ->
                if (reel.id == reelId) {
                    val newLiked = !reel.isLikedByMe
                    val newCount = if (newLiked) reel.likesCount + 1 else (reel.likesCount - 1).coerceAtLeast(0)
                    reel.copy(isLikedByMe = newLiked, likesCount = newCount)
                } else reel
            }
            state.copy(reels = updatedReels)
        }
    }

    fun toggleFollowCreator(username: String) {
        _uiState.update { state ->
            val updatedReels = state.reels.map { reel ->
                if (reel.creatorUsername == username) {
                    reel.copy(isFollowingCreator = !reel.isFollowingCreator)
                } else reel
            }
            state.copy(reels = updatedReels)
        }
    }

    fun setSelectedPostDetail(post: Post?) {
        _uiState.update { it.copy(selectedPostDetail = post) }
    }

    fun logIn(name: String, username: String) {
        _uiState.update { state ->
            val user = state.currentUser.copy(
                name = name,
                username = username
            )
            state.copy(
                isLoggedIn = true,
                currentUser = user,
                currentTab = ScreenTab.HOME
            )
        }
    }

    fun logOut() {
        _uiState.update { it.copy(isLoggedIn = false) }
    }

    private fun extractHashtags(text: String): List<String> {
        val regex = Regex("#\\w+")
        return regex.findAll(text).map { it.value.removePrefix("#") }.toList()
    }
}
