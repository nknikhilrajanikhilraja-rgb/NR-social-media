package com.example.model

data class User(
    val id: String,
    val name: String,
    val username: String,
    val avatarUrl: String,
    val bio: String,
    val website: String = "",
    val location: String = "",
    val isVerified: Boolean = false,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val postsCount: Int = 0,
    val isFollowedByMe: Boolean = false
)

data class Comment(
    val id: String,
    val authorName: String,
    val authorUsername: String,
    val authorAvatarUrl: String,
    val text: String,
    val timestamp: String,
    val likesCount: Int = 0,
    val isLikedByMe: Boolean = false
)

data class Post(
    val id: String,
    val userId: String,
    val authorName: String,
    val authorUsername: String,
    val authorAvatarUrl: String,
    val isVerified: Boolean = false,
    val timestamp: String,
    val caption: String,
    val mediaUrl: String,
    val isVideo: Boolean = false,
    val videoDuration: String = "",
    val likesCount: Int = 0,
    val isLikedByMe: Boolean = false,
    val commentsCount: Int = 0,
    val isSavedByMe: Boolean = false,
    val location: String? = null,
    val tags: List<String> = emptyList(),
    val comments: List<Comment> = emptyList()
)

data class Reel(
    val id: String,
    val creatorName: String,
    val creatorUsername: String,
    val creatorAvatarUrl: String,
    val caption: String,
    val musicTrack: String,
    val videoThumbnailUrl: String,
    val likesCount: Int = 0,
    val isLikedByMe: Boolean = false,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isFollowingCreator: Boolean = false,
    val comments: List<Comment> = emptyList()
)

data class Story(
    val id: String,
    val userId: String,
    val username: String,
    val avatarUrl: String,
    val isViewed: Boolean = false,
    val mediaUrl: String,
    val isCurrentUser: Boolean = false
)

enum class ScreenTab {
    HOME,
    EXPLORE,
    REELS,
    PROFILE
}
