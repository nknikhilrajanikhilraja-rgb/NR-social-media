package com.example.data

import com.example.model.Comment
import com.example.model.Post
import com.example.model.Reel
import com.example.model.Story
import com.example.model.User

object MockDataProvider {

    val currentUser = User(
        id = "user_me",
        name = "Nikhil Raja",
        username = "nikhilraja",
        avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80",
        bio = "Founder & Tech Visionary ⚡ Building the next generation of social with NR. AI, design systems & mobile architectures.",
        website = "https://nr.social",
        location = "San Francisco, CA",
        isVerified = true,
        followersCount = 14820,
        followingCount = 428,
        postsCount = 9,
        isFollowedByMe = false
    )

    val otherUsers = listOf(
        User(
            id = "user_elena",
            name = "Elena Rostova",
            username = "elena_visuals",
            avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=80",
            bio = "Visual artist & cinematic photographer 📸 Capturing neon cityscapes & quiet moments.",
            website = "https://elenarostova.art",
            location = "Tokyo, Japan",
            isVerified = true,
            followersCount = 48200,
            followingCount = 312,
            postsCount = 42,
            isFollowedByMe = true
        ),
        User(
            id = "user_marcus",
            name = "Marcus Vance",
            username = "marcus_tech",
            avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80",
            bio = "Hardware hacker & creative developer 💻 Building AI companions & robotics.",
            website = "https://marcusvance.io",
            location = "Austin, TX",
            isVerified = false,
            followersCount = 9340,
            followingCount = 185,
            postsCount = 28,
            isFollowedByMe = false
        ),
        User(
            id = "user_sophia",
            name = "Sophia Chen",
            username = "sophiatravels",
            avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500&auto=format&fit=crop&q=80",
            bio = "Wanderlust enthusiast ✈️ Explored 42 countries. Sharing hidden gems & aesthetic stays.",
            website = "https://sophiatravels.blog",
            location = "Nomad / Bali",
            isVerified = true,
            followersCount = 125000,
            followingCount = 610,
            postsCount = 154,
            isFollowedByMe = true
        )
    )

    fun getInitialStories(): List<Story> = listOf(
        Story(
            id = "story_me",
            userId = "user_me",
            username = "Your Story",
            avatarUrl = currentUser.avatarUrl,
            isViewed = false,
            mediaUrl = "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&auto=format&fit=crop&q=80",
            isCurrentUser = true
        ),
        Story(
            id = "story_1",
            userId = "user_elena",
            username = "elena_visuals",
            avatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=80",
            isViewed = false,
            mediaUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80"
        ),
        Story(
            id = "story_2",
            userId = "user_marcus",
            username = "marcus_tech",
            avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80",
            isViewed = false,
            mediaUrl = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80"
        ),
        Story(
            id = "story_3",
            userId = "user_sophia",
            username = "sophiatravels",
            avatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500&auto=format&fit=crop&q=80",
            isViewed = true,
            mediaUrl = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800&auto=format&fit=crop&q=80"
        )
    )

    fun getInitialPosts(): List<Post> = listOf(
        Post(
            id = "post_1",
            userId = "user_elena",
            authorName = "Elena Rostova",
            authorUsername = "elena_visuals",
            authorAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=80",
            isVerified = true,
            timestamp = "15m ago",
            caption = "Midnight reflections in Shibuya. Rain gives the city a cyberpunk mirror effect that never gets old. What vibe do you prefer: rainy night or sunny morning? 🌃✨ #TokyoVibes #Cyberpunk #Photography",
            mediaUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1000&auto=format&fit=crop&q=80",
            isVideo = false,
            likesCount = 2841,
            isLikedByMe = true,
            commentsCount = 42,
            isSavedByMe = false,
            location = "Shibuya Crossing, Tokyo",
            tags = listOf("TokyoVibes", "Cyberpunk", "Photography"),
            comments = listOf(
                Comment(
                    id = "c1",
                    authorName = "Nikhil Raja",
                    authorUsername = "nikhilraja",
                    authorAvatarUrl = currentUser.avatarUrl,
                    text = "The color grading on this is astonishing Elena! 👏",
                    timestamp = "10m ago",
                    likesCount = 14,
                    isLikedByMe = true
                ),
                Comment(
                    id = "c2",
                    authorName = "Marcus Vance",
                    authorUsername = "marcus_tech",
                    authorAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80",
                    text = "Rainy night any day. Perfect coding ambiance.",
                    timestamp = "5m ago",
                    likesCount = 8
                )
            )
        ),
        Post(
            id = "post_2",
            userId = "user_me",
            authorName = "Nikhil Raja",
            authorUsername = "nikhilraja",
            authorAvatarUrl = currentUser.avatarUrl,
            isVerified = true,
            timestamp = "1h ago",
            caption = "Proud to introduce the first look at NR Social! A completely redesigned social experience engineered for speed, privacy, and genuine creator connections. Blue theme, dark navy depth, zero clutter. 🚀💙 Let me know your thoughts!",
            mediaUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1000&auto=format&fit=crop&q=80",
            isVideo = false,
            likesCount = 3892,
            isLikedByMe = true,
            commentsCount = 67,
            isSavedByMe = true,
            location = "Silicon Valley, CA",
            tags = listOf("NRSocial", "TechLaunch", "Innovation"),
            comments = listOf(
                Comment(
                    id = "c3",
                    authorName = "Elena Rostova",
                    authorUsername = "elena_visuals",
                    authorAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=80",
                    text = "The dark navy palette is so easy on the eyes! Huge congratulations Nikhil! 🎉",
                    timestamp = "45m ago",
                    likesCount = 29,
                    isLikedByMe = true
                )
            )
        ),
        Post(
            id = "post_3",
            userId = "user_marcus",
            authorName = "Marcus Vance",
            authorUsername = "marcus_tech",
            authorAvatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80",
            isVerified = false,
            timestamp = "3h ago",
            caption = "Testing our new low-latency wireless camera rig outdoors. 4K 60fps streaming with custom heat dissipation frame. 🎥⚡ Tap to play preview!",
            mediaUrl = "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=1000&auto=format&fit=crop&q=80",
            isVideo = true,
            videoDuration = "0:45",
            likesCount = 1420,
            isLikedByMe = false,
            commentsCount = 18,
            isSavedByMe = false,
            location = "Austin Robotics Lab",
            tags = listOf("Hardware", "Filmmaking", "TechDemo")
        ),
        Post(
            id = "post_4",
            userId = "user_sophia",
            authorName = "Sophia Chen",
            authorUsername = "sophiatravels",
            authorAvatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500&auto=format&fit=crop&q=80",
            isVerified = true,
            timestamp = "5h ago",
            caption = "Sunrise above the clouds in the Swiss Alps. Breathing in this crisp mountain air reminds us why preserving our wild world matters. 🏔️✨ Save this spot for your next itinerary! #Alps #TravelGoals #Nature",
            mediaUrl = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1000&auto=format&fit=crop&q=80",
            isVideo = false,
            likesCount = 5890,
            isLikedByMe = false,
            commentsCount = 94,
            isSavedByMe = true,
            location = "Zermatt, Switzerland",
            tags = listOf("Alps", "TravelGoals", "Nature")
        )
    )

    fun getUserPosts(userId: String): List<Post> {
        return if (userId == "user_me") {
            listOf(
                Post(
                    id = "my_post_1",
                    userId = "user_me",
                    authorName = currentUser.name,
                    authorUsername = currentUser.username,
                    authorAvatarUrl = currentUser.avatarUrl,
                    isVerified = true,
                    timestamp = "1h ago",
                    caption = "NR Social v1.0 architecture review with the engineering team. Modular, reactive, clean. 🚀",
                    mediaUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop&q=80",
                    isVideo = false,
                    likesCount = 3892,
                    commentsCount = 67
                ),
                Post(
                    id = "my_post_2",
                    userId = "user_me",
                    authorName = currentUser.name,
                    authorUsername = currentUser.username,
                    authorAvatarUrl = currentUser.avatarUrl,
                    isVerified = true,
                    timestamp = "2d ago",
                    caption = "Midnight code session with dual ultra-wides. Dark theme everywhere. 💻☕",
                    mediaUrl = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
                    isVideo = false,
                    likesCount = 1920,
                    commentsCount = 33
                ),
                Post(
                    id = "my_post_3",
                    userId = "user_me",
                    authorName = currentUser.name,
                    authorUsername = currentUser.username,
                    authorAvatarUrl = currentUser.avatarUrl,
                    isVerified = true,
                    timestamp = "4d ago",
                    caption = "Demo reel showing the new dynamic feed transition physics! 📱✨",
                    mediaUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
                    isVideo = true,
                    videoDuration = "0:30",
                    likesCount = 2410,
                    commentsCount = 48
                ),
                Post(
                    id = "my_post_4",
                    userId = "user_me",
                    authorName = currentUser.name,
                    authorUsername = currentUser.username,
                    authorAvatarUrl = currentUser.avatarUrl,
                    isVerified = true,
                    timestamp = "1w ago",
                    caption = "Early morning brainstorming walk at the Golden Gate Bridge. 🌁",
                    mediaUrl = "https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=800&auto=format&fit=crop&q=80",
                    isVideo = false,
                    likesCount = 1530,
                    commentsCount = 21
                ),
                Post(
                    id = "my_post_5",
                    userId = "user_me",
                    authorName = currentUser.name,
                    authorUsername = currentUser.username,
                    authorAvatarUrl = currentUser.avatarUrl,
                    isVerified = true,
                    timestamp = "2w ago",
                    caption = "Minimalist workstation setup in navy and slate. What keyboard switch are you typing on?",
                    mediaUrl = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80",
                    isVideo = false,
                    likesCount = 2105,
                    commentsCount = 59
                ),
                Post(
                    id = "my_post_6",
                    userId = "user_me",
                    authorName = currentUser.name,
                    authorUsername = currentUser.username,
                    authorAvatarUrl = currentUser.avatarUrl,
                    isVerified = true,
                    timestamp = "3w ago",
                    caption = "Testing video rendering pipelines on Android with hardware encoding acceleration. 🎥",
                    mediaUrl = "https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&auto=format&fit=crop&q=80",
                    isVideo = true,
                    videoDuration = "0:15",
                    likesCount = 980,
                    commentsCount = 14
                )
            )
        } else {
            getInitialPosts().filter { it.userId == userId }
        }
    }

    fun getInitialReels(): List<Reel> = listOf(
        Reel(
            id = "reel_1",
            creatorName = "Nikhil Raja",
            creatorUsername = "nikhilraja",
            creatorAvatarUrl = currentUser.avatarUrl,
            caption = "Building NR Social from the ground up! Here's how we achieved 60fps feed animations in Jetpack Compose 🚀⚡ #AndroidDev #Compose #TechBuilding",
            musicTrack = "NR Original Soundtrack • Cyber Soundwaves",
            videoThumbnailUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1080&auto=format&fit=crop&q=80",
            likesCount = 12400,
            isLikedByMe = true,
            commentsCount = 380,
            sharesCount = 1420,
            isFollowingCreator = false
        ),
        Reel(
            id = "reel_2",
            creatorName = "Elena Rostova",
            creatorUsername = "elena_visuals",
            creatorAvatarUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=80",
            caption = "Rainy neon aesthetic walk through Shinjuku alleyways at 2 AM 🌧️ Neon lights hit different. #Tokyo #Aesthetic #Cinematic",
            musicTrack = "Midnight Lo-Fi • Tokyo Echoes",
            videoThumbnailUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1080&auto=format&fit=crop&q=80",
            likesCount = 34500,
            isLikedByMe = false,
            commentsCount = 912,
            sharesCount = 4200,
            isFollowingCreator = true
        ),
        Reel(
            id = "reel_3",
            creatorName = "Sophia Chen",
            creatorUsername = "sophiatravels",
            creatorAvatarUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500&auto=format&fit=crop&q=80",
            caption = "Hidden emerald waterfalls tucked deep inside the rainforest! 🌴💦 Would you dive in?",
            musicTrack = "Nature Acoustics • Mountain Echoes",
            videoThumbnailUrl = "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=1080&auto=format&fit=crop&q=80",
            likesCount = 52100,
            isLikedByMe = true,
            commentsCount = 1340,
            sharesCount = 7600,
            isFollowingCreator = true
        )
    )
}
