package com.example.ui.home

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Post
import com.example.model.Story
import com.example.model.User
import com.example.ui.components.BackendRequirementDialog
import com.example.ui.components.DemoBackendBanner
import com.example.ui.components.NrHeaderBrand
import com.example.ui.components.PostItem
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueLight
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun HomeScreen(
    posts: List<Post>,
    stories: List<Story>,
    currentUser: User,
    onCreatePostClick: () -> Unit,
    onLikeToggle: (postId: String) -> Unit,
    onSaveToggle: (postId: String) -> Unit,
    onCommentClick: (Post) -> Unit,
    onAuthorClick: (userId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showBackendNoticeDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDeep)
    ) {
        // App Header Bar with Original NR Brand
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavySurface)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            NrHeaderBrand(
                modifier = Modifier.testTag("app_header_brand"),
                badgeSize = 34.dp
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Backend requirement info trigger
                IconButton(
                    onClick = { showBackendNoticeDialog = true },
                    modifier = Modifier.testTag("backend_info_icon_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudQueue,
                        contentDescription = "Backend Status",
                        tint = NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Create Post (+)
                IconButton(
                    onClick = onCreatePostClick,
                    modifier = Modifier.testTag("create_post_header_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddCircle,
                        contentDescription = "Create Post",
                        tint = ElectricBlueLight,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Notifications with badge
                IconButton(
                    onClick = {
                        Toast.makeText(context, "Notifications • 3 new demo alerts", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("notifications_button")
                ) {
                    BadgedBox(
                        badge = {
                            Badge(
                                containerColor = NeonCyan,
                                contentColor = NavyDeep
                            ) {
                                Text("3", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsNone,
                            contentDescription = "Notifications",
                            tint = TextPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Direct messages
                IconButton(
                    onClick = {
                        Toast.makeText(context, "Direct Messages • 2 unread chats", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("messages_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "Messages",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Home Feed LazyColumn (Stories + Demo Banner + Posts)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Stories Tray
            item {
                StoriesTray(
                    stories = stories,
                    currentUser = currentUser,
                    onStoryClick = { story ->
                        Toast.makeText(context, "Viewing story by ${story.username} (Demo)", Toast.LENGTH_SHORT).show()
                    },
                    onAddStoryClick = {
                        Toast.makeText(context, "Add to Story (Demo mode)", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            // Demo Backend Notice Banner
            item {
                Box(modifier = Modifier.padding(horizontal = 14.dp)) {
                    DemoBackendBanner(
                        title = "DEMO FEED • BACKEND REQUIRED",
                        subtitle = "Viewing sample social posts. Real-time multi-device feed synchronization requires Cloud Firestore & Storage backend.",
                        onInfoClick = { showBackendNoticeDialog = true },
                        modifier = Modifier.testTag("home_backend_banner")
                    )
                }
            }

            // Posts Feed
            items(posts, key = { it.id }) { post ->
                Box(modifier = Modifier.padding(horizontal = 12.dp)) {
                    PostItem(
                        post = post,
                        onLikeToggle = { onLikeToggle(post.id) },
                        onSaveToggle = { onSaveToggle(post.id) },
                        onCommentClick = { onCommentClick(post) },
                        onShareClick = {
                            Toast.makeText(context, "Sharing post by ${post.authorUsername}", Toast.LENGTH_SHORT).show()
                        },
                        onAuthorClick = { onAuthorClick(post.userId) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showBackendNoticeDialog) {
        BackendRequirementDialog(onDismiss = { showBackendNoticeDialog = false })
    }
}

@Composable
private fun StoriesTray(
    stories: List<Story>,
    currentUser: User,
    onStoryClick: (Story) -> Unit,
    onAddStoryClick: () -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(NavySurface)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Spacer(modifier = Modifier.width(4.dp)) }

        // Current User Story item (+ Add Story)
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(68.dp)
                    .clickable { onAddStoryClick() }
                    .testTag("add_story_button")
            ) {
                Box(
                    modifier = Modifier.size(62.dp),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    AsyncImage(
                        model = currentUser.avatarUrl,
                        contentDescription = "Your Story",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, NavySurfaceVariant, CircleShape)
                    )
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(ElectricBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Story",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Text(
                    text = "Your Story",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Friends' Stories
        items(stories.filter { !it.isCurrentUser }, key = { it.id }) { story ->
            val ringBrush = Brush.linearGradient(
                listOf(NeonCyan, ElectricBlueLight, ElectricBlue)
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(68.dp)
                    .clickable { onStoryClick(story) }
                    .testTag("story_${story.id}")
            ) {
                Box(
                    modifier = Modifier
                        .size(62.dp)
                        .clip(CircleShape)
                        .background(if (story.isViewed) Brush.linearGradient(listOf(NavySurfaceVariant, NavySurfaceVariant)) else ringBrush)
                        .padding(2.5.dp)
                ) {
                    AsyncImage(
                        model = story.avatarUrl,
                        contentDescription = story.username,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
                Text(
                    text = story.username,
                    color = TextPrimary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        item { Spacer(modifier = Modifier.width(4.dp)) }
    }
}
