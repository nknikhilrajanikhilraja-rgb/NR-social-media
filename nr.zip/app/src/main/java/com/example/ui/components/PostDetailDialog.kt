package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.Post
import com.example.ui.theme.NavySurfaceElevated

@Composable
fun PostDetailDialog(
    post: Post,
    onDismiss: () -> Unit,
    onLikeToggle: () -> Unit,
    onSaveToggle: () -> Unit,
    onCommentClick: () -> Unit,
    onShareClick: () -> Unit,
    onAuthorClick: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(20.dp)),
            color = NavySurfaceElevated,
            tonalElevation = 6.dp
        ) {
            Box(modifier = Modifier.padding(8.dp)) {
                PostItem(
                    post = post,
                    onLikeToggle = onLikeToggle,
                    onSaveToggle = onSaveToggle,
                    onCommentClick = onCommentClick,
                    onShareClick = onShareClick,
                    onAuthorClick = onAuthorClick
                )
            }
        }
    }
}
