package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DemoBadgeBg
import com.example.ui.theme.DemoBadgeText
import com.example.ui.theme.ElectricBlueLight
import com.example.ui.theme.NavySurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DemoBackendBanner(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onInfoClick: (() -> Unit)? = null
) {
    var showDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DemoBadgeBg)
            .border(1.dp, DemoBadgeText.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .clickable {
                if (onInfoClick != null) onInfoClick() else showDialog = true
            }
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CloudQueue,
                contentDescription = "Backend Demo Notice",
                tint = DemoBadgeText,
                modifier = Modifier.size(20.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = DemoBadgeText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = subtitle,
                    color = Color(0xFFFDE68A),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "More details",
                tint = DemoBadgeText.copy(alpha = 0.8f),
                modifier = Modifier.size(16.dp)
            )
        }
    }

    if (showDialog) {
        BackendRequirementDialog(onDismiss = { showDialog = false })
    }
}

@Composable
fun BackendRequirementDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavySurfaceElevated,
        icon = {
            Icon(
                imageVector = Icons.Default.CloudQueue,
                contentDescription = null,
                tint = ElectricBlueLight,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "Backend Architecture Notice",
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "This preview of NR Social currently runs with local in-memory state. In a full production environment, the following cloud backend services are required:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                BackendRequirementItem(
                    title = "Authentication",
                    description = "Firebase Auth or OAuth 2.0 to securely register, verify emails, and manage sessions."
                )
                BackendRequirementItem(
                    title = "Database / Feed",
                    description = "Cloud Firestore to persist posts, comments, likes, followers, and user profile data."
                )
                BackendRequirementItem(
                    title = "Media Storage & CDN",
                    description = "Cloud Storage to transcode, store, and stream high-res photos and video Reels."
                )
                BackendRequirementItem(
                    title = "Realtime Sync",
                    description = "WebSocket or Firestore listeners for live notifications and instant direct messages."
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Understood", color = ElectricBlueLight, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun BackendRequirementItem(title: String, description: String) {
    Column {
        Text(
            text = "• $title",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = description,
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 12.dp, top = 2.dp)
        )
    }
}
