package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NrDarkColorScheme = darkColorScheme(
    primary = ElectricBlueLight,
    onPrimary = Color.White,
    primaryContainer = NavySurfaceElevated,
    onPrimaryContainer = NeonCyan,
    secondary = NeonCyan,
    onSecondary = NavyDeep,
    secondaryContainer = NavySurfaceVariant,
    onSecondaryContainer = TextPrimary,
    tertiary = IndigoGlow,
    onTertiary = Color.White,
    background = NavyDeep,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavySurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BorderMuted,
    outlineVariant = BorderHighlight
)

@Composable
fun NrSocialTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NrDarkColorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    NrSocialTheme(content = content)
}
