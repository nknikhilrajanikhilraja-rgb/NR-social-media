package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Navy & Blue Theme Colors
val NavyDeep = Color(0xFF080D1A)
val NavySurface = Color(0xFF0F172A)
val NavySurfaceVariant = Color(0xFF1E293B)
val NavySurfaceElevated = Color(0xFF1A2744)

val ElectricBlue = Color(0xFF2563EB)
val ElectricBlueLight = Color(0xFF3B82F6)
val NeonCyan = Color(0xFF38BDF8)
val IndigoGlow = Color(0xFF6366F1)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val BorderMuted = Color(0xFF1E293B)
val BorderHighlight = Color(0xFF334155)

val HeartRed = Color(0xFFEF4444)
val VerifiedBadgeColor = Color(0xFF38BDF8)
val DemoBadgeBg = Color(0x33F59E0B)
val DemoBadgeText = Color(0xFFFBBF24)
