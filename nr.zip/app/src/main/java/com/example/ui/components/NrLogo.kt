package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ElectricBlueLight
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun NrLogoBadge(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp
) {
    val cornerRadius = size * 0.28f
    val gradientBrush = Brush.linearGradient(
        colors = listOf(NeonCyan, ElectricBlueLight, ElectricBlue)
    )
    val backgroundBrush = Brush.verticalGradient(
        colors = listOf(NavySurfaceVariant, NavyDeep)
    )

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(backgroundBrush)
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.8f), ElectricBlue.copy(alpha = 0.4f))),
                shape = RoundedCornerShape(cornerRadius)
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "NR",
            fontSize = (size.value * 0.48f).sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.SansSerif,
            style = androidx.compose.ui.text.TextStyle(
                brush = gradientBrush,
                letterSpacing = (-0.5).sp
            )
        )
    }
}

@Composable
fun NrHeaderBrand(
    modifier: Modifier = Modifier,
    badgeSize: Dp = 36.dp
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        NrLogoBadge(size = badgeSize)
        Column {
            Text(
                text = "NR",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
            Text(
                text = "SOCIAL",
                color = NeonCyan,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.5.sp
            )
        }
    }
}
